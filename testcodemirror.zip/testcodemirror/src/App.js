import React, { Component } from 'react';

import './App.css';

import {UnControlled as CodeMirror} from 'react-codemirror2'


import 'codemirror/lib/codemirror.css'
import 'codemirror/theme/material-darker.css'
import 'codemirror/addon/hint/show-hint.css'
import 'codemirror/mode/sql/sql.js'
import 'codemirror/addon/lint/lint.js'
import 'codemirror/addon/hint/sql-hint.js'
import 'codemirror/addon/hint/show-hint.js'
import 'codemirror/addon/comment/comment.js'



class App extends Component {
    constructor(props) {
        super(props)
        this.instance = null;
    }
    componentDidMount() {
        console.log(this.instance)
    }
    
    render() {
        return (
            <div className="App">
                <CodeMirror
                    ref="CodeMirror"
                    editorDidMount={editor => { this.instance = editor }}
                    value={`SELECT *\n FROM tab2\n`}
                    options={{
                        mode: 'sql',
                        theme: 'material-darker',
                        lineNumbers: true,
                        autocorrect: true,
                        autocomplete    : true,
                        autocapitalize: false,
                        showGutter: true
                    }}
                    onKeyUp={(cm, event) => {
                        if (!cm.state.completionActive &&   /*Enables keyboard navigation in autocomplete list*/
                            event.keyCode > 64 && event.keyCode < 91) {
                            this.instance.showHint({completeSingle: false});
                        }
                    }}
                    onChange={(editor, data, value) => {
                        console.log(editor, data, value);
                    }}
                    
                />
            
            </div>
        );
    }
}

export default App;
